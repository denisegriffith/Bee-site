
Bee-lightful Apiary — Netlify-ready Site
---------------------------------------

What this package is:
- A small static site that uses files under /content for editable content.
- Netlify CMS admin is available at /admin after you deploy to Netlify and enable Identity + Git Gateway.

How to deploy to Netlify (recommended):
1. Create a Git repository (GitHub, GitLab, or Bitbucket) and push this project to the repo's main branch.
2. Sign up at https://app.netlify.com and choose "New site from Git". Connect your repo and deploy.
3. In Netlify site settings -> Identity, enable Identity service.
4. Under Identity settings, enable "Generic Git Gateway" (or "Git Gateway") and follow prompts to connect your repo (you may need to enable Netlify OAuth with your Git provider).
5. In Netlify > Identity > Invite users or enable "Open registration" to create an account. Then visit https://your-site.netlify.app/admin to log into Netlify CMS.
6. Once logged in, you'll be able to edit the homepage content (content/home.md) and create/edit products (content/products/*.json). Each change commits to your Git branch and triggers a rebuild/deploy on Netlify.

Notes:
- Replace the placeholder contact email in scripts.js with your real email.
- Product images uploaded via the CMS will be stored in the repo's `assets/` folder when using Git Gateway.
- If you'd rather have a hosted shop with built-in checkout and admin (hosted login, payments, inventory), Shopify might be a better choice. I can prepare a Shopify product CSV and theme snippets for import.

If you want, I can:
A) Push this project to a GitHub repo for you (you'd need to give me a repo URL or add me as a collaborator) — I cannot push to your GitHub without access.
B) Walk you through each Netlify step and help set your Identity and CMS settings live.
C) Prepare a Shopify import instead.

