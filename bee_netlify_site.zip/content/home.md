# Our Story

We tend hives among blossoms and orchard trees, harvesting small batches of unprocessed honey. Each jar tastes like the season it came from — raw, natural, and unforgettable.

Join our newsletter to hear about seasonal fruits and new batches.