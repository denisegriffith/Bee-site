
// Load homepage markdown and products JSONs under /content
async function loadHome(){
  try{
    const res = await fetch('content/home.md');
    if(res.ok){
      const md = await res.text();
      document.getElementById('about-body').innerHTML = mdToHtml(md);
    }
  }catch(e){console.warn(e)}
}
async function loadProducts(){
  const container = document.getElementById('products');
  container.innerHTML='';
  // fetch all product json files
  const p1 = await fetch('content/products/honey-12oz.json').then(r=>r.json());
  const p2 = await fetch('content/products/honey-sticks.json').then(r=>r.json());
  const p3 = await fetch('content/products/beeswax-candle.json').then(r=>r.json());
  const products = [p1,p2,p3];
  products.forEach(p=>{
    const card = document.createElement('div'); card.className='card';
    card.innerHTML = `<img src="${p.image}" alt="${p.name}"><h4>${p.name}</h4><div class="price">$${p.price.toFixed(2)}</div><p>${p.description}</p><div class="add"><button onclick="addToCart('${p.id}')">Add to Cart</button></div>`;
    container.appendChild(card);
  });
}
// simple markdown to html for basic paragraphs and headings
function mdToHtml(md){
  return md.split('\n\n').map(par=>{
    if(par.startsWith('# ')) return '<h2>'+par.replace('# ','')+'</h2>';
    return '<p>'+par.replace(/\n/g,' ')+'</p>';
  }).join('');
}
// Cart functions (same as earlier)
let cart={};
function addToCart(id){cart[id]=(cart[id]||0)+1;updateCartUI();openCart()}
function updateCartUI(){const itemsDiv=document.getElementById('cart-items');if(!itemsDiv) return;itemsDiv.innerHTML='';let total=0;const productsList=['honey-12oz','honey-sticks','beeswax-candle'];for(const id in cart){const qty=cart[id];let p; if(id==='honey-12oz') p={name:'Wildflower Raw Honey — 12oz',price:12,image:'assets/hero.jpg'}; if(id==='honey-sticks') p={name:'Honey Sticks — Pack of 10',price:6,image:'assets/flower.jpg'}; if(id==='beeswax-candle') p={name:'Beeswax Candle — Small',price:8,image:'assets/hive.jpg'}; const div=document.createElement('div');div.className='cart-item';div.innerHTML=`<img src="${p.image}"><div><strong>${p.name}</strong><div>Qty: ${qty}</div><div>$${(p.price*qty).toFixed(2)}</div></div>`;itemsDiv.appendChild(div); total+=p.price*qty;} document.getElementById('cart-total').textContent='Total: $'+total.toFixed(2);}
function openCart(){document.getElementById('cart').classList.add('open')}
document.getElementById && document.getElementById('checkout-btn') && document.getElementById('checkout-btn').addEventListener('click', ()=>{alert('Payments coming soon. Email hello@beelightful.example to place an order.');});
// init
loadHome(); loadProducts();
